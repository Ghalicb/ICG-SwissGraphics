Assignment 1

The most difficult part was to derive the theoretical part. The plane intersection part and the cylinder implementation was fine.

Workload:
 Ghali Chraibi: 1/3
 Daniel Filipe Nunes Silva: 1/3
 Samuel Chassot: 1/3 