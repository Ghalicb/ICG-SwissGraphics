# Assignment 5 : Transformations and Viewing

## Description
In this assignment, we built a scene containing several objects (planets from the solar system, a moon and a spaceship), as well as an eye to observe this scene. We also implemented the basic rendering pipeline to render each object with its corresponding texture. We finally added keyboard events to interract with the eye.

- We spent most of the time understanding how matrices modify objects positions and how they should be combined.
- Our first approach was to update planets' positions step by step. But we finally decided to make use of the stored angle of orbit to compute the rotation from the initial position.

## Workload
Daniel Filipe NUNES SILVA : 1/3  
Ghali CHRAIBI : 1/3  
Samuel CHASSOT : 1/3
