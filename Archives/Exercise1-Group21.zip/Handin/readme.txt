Assignment 1 : Planes and Cylinders

• In the first part of the assignment, we implemented ray intersections with planes using mainly the implicit equation of a plane, derived in class.
• Then, we derived the implicit equation of a cylinder (cf. TheoryExercise.pdf), which was for us the most difficult part of the week.
• Finally, having the implicit equation of the cylinder, we implemented ray intersections with cylinders without many difficulties.

Workload :
 Ghali Chraibi: 1/3
 Daniel Filipe Nunes Silva: 1/3
 Samuel Chassot: 1/3 