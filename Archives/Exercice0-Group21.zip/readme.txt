ASSIGNMENT 0 : "Hello World"

We solve this exercice by changing the color of the background in the solid_color scene from black to red.

Daniel Filipe NUNES SILVA : 33%
Ghali CHRAIBI : 33%
Samuel CHASSOT : 33%