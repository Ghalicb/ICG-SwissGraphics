# Final Project Proposal

## Description
Please find our HTML file describing our future project and the papers, that inspired us.

## Workload
Daniel Filipe NUNES SILVA : 1/3  
Ghali CHRAIBI : 1/3  
Samuel CHASSOT : 1/3
