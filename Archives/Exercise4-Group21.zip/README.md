# Assignment 4 : OpenGL "Hello World"

## Description
Needed dependencies installation

## Workload
Daniel Filipe NUNES SILVA : 1/3  
Ghali CHRAIBI : 1/3  
Samuel CHASSOT : 1/3
