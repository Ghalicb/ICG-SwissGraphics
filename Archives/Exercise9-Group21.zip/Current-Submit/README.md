# Assignment 9 : Perlin Noise, Procedural Terrain

## Description

In this assignment, we implemented perlin noise in 1D and 2D, as well as fractional Brownian motion and turbulance noises.  

This allowed us to implement simple texture such as wood, marble and a basic map (water, grass and mountain) using known functions.

Finally, we produced a 3D terrain, which was the most demanding part.  

## Workload
Daniel Filipe NUNES SILVA : 1/3  
Ghali CHRAIBI : 1/3  
Samuel CHASSOT : 1/3  
