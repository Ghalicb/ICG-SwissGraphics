# Assignment 7 : Shadows and Cube Mapping

## Description
In this assignment, we implemented a real-time shadowing technique for multiple omni-directional point lights.

First, we implemented the view and projection matrices for a cube face. For the view matrix, we struggled a bit figuring out which matrices to use in order to switch between the coordinates systems.

Then, we worked on the fragment shader and implemented Phong lighting in it. Shadows were handled using shadow map. Signs of vectors and coordinates systems were also a challenging part. 

## Workload
Daniel Filipe NUNES SILVA : 1/3  
Ghali CHRAIBI : 1/3  
Samuel CHASSOT : 1/3    
